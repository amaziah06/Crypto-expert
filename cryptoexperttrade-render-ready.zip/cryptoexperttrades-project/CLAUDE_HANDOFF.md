# Claude handoff: CryptoExpertTrade project

You are continuing an existing runnable full-stack project, not starting over and not writing another prompt.

Reference: https://cryptoexperttrades.vercel.app/

1. Inspect every file before changing anything. The reference site was reachable, but automated text extraction returned no page content. Therefore, visually inspect the reference in a browser if available and compare screenshots before claiming an exact match.
2. Preserve and improve the current React + Vite frontend, Express API, SQLite persistence, bcrypt password hashing, JWT authentication, user dashboard, admin dashboard, and responsive dark crypto-market interface.
3. Install dependencies and run the app. Fix all compile/runtime errors and test the main flows.
4. Improve the crypto UI to match the reference's actual visible layout, colors, fonts, hero artwork, buttons, market sections, page routes, and mobile behavior. Do not invent private pages or claim exactness without screenshots.
5. Verify API auth, role checks, input validation, rate limiting, and database transaction behavior. Never trust client-side balances or user-supplied admin roles.
6. Keep deposits, withdrawals, and investment-like flows explicitly simulated. Do not enable real-money payments, custody, trading, or promised returns without legitimate providers and required legal/security review.
7. Use real market-data APIs only with proper attribution and graceful failure handling. Never label hardcoded prices as live.
8. Provide clear setup and deployment instructions, a list of completed tests, and any remaining requirements.

Deliver the updated project files and a concise change log. Do not replace the project with a static landing page.
